import {
  ArrowUpRight,
  BookOpen,
  Github,
  Hammer,
  Linkedin,
  Mail,
  ShieldCheck,
  Terminal,
  TriangleAlert,
} from "lucide-react";
import { Reveal, SectionHeading } from "./Reveal";
import { useReveal } from "@/hooks/use-reveal";
import {
  contacts,
  credentials,
  journey,
  labs,
  projects,
  skillGroups,
} from "@/data/portfolio";

const aboutCards = [
  {
    icon: BookOpen,
    title: "Learn",
    body: "Continuously developing cybersecurity knowledge.",
  },
  { icon: Hammer, title: "Build", body: "Creating practical security projects." },
  {
    icon: ShieldCheck,
    title: "Secure",
    body: "Understanding vulnerabilities and defensive security.",
  },
];

export function About() {
  return (
    <section id="about" className="mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-24">
      <SectionHeading
        eyebrow="// about"
        title="About Me"
        intro="Hi, I'm Vishal. I'm currently developing my skills in cybersecurity through hands-on projects, labs, and continuous learning. I'm interested in ethical hacking, network security, Linux, vulnerability analysis, and security automation."
      />
      <div className="mt-10 grid gap-4 sm:grid-cols-3">
        {aboutCards.map((card, i) => (
          <Reveal key={card.title} delay={i * 90}>
            <article className="glass h-full rounded-2xl p-6 transition-transform duration-300 hover:-translate-y-1">
              <span className="grid h-10 w-10 place-items-center rounded-lg border border-primary/30 bg-primary/10">
                <card.icon className="h-5 w-5 text-primary" aria-hidden />
              </span>
              <h3 className="mt-4 font-mono text-sm uppercase tracking-widest text-primary">
                {card.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{card.body}</p>
            </article>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function SkillBar({ name, level }: { name: string; level: number }) {
  const { ref, visible } = useReveal<HTMLDivElement>();
  return (
    <div ref={ref}>
      <div className="flex items-center justify-between gap-3">
        <span className="min-w-0 truncate text-sm text-foreground/90">{name}</span>
        <span className="shrink-0 font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
          learning
        </span>
      </div>
      <div
        className="mt-2 h-1.5 overflow-hidden rounded-full bg-secondary"
        role="img"
        aria-label={`${name}: currently learning`}
      >
        <div
          className="h-full rounded-full bg-gradient-to-r from-primary to-accent transition-[width] duration-1000 ease-out"
          style={{ width: visible ? `${level}%` : "0%" }}
        />
      </div>
    </div>
  );
}

export function Skills() {
  return (
    <section id="skills" className="mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-24">
      <SectionHeading
        eyebrow="// skills"
        title="Skills In Progress"
        intro="These are the areas I'm actively learning and practising — not expert-level claims."
      />
      <div className="mt-10 grid gap-4 lg:grid-cols-6">
        {skillGroups.map((group, i) => (
          <Reveal key={group.title} delay={i * 80} className={group.span}>
            <article className="glass h-full rounded-2xl p-6 transition-shadow duration-300 hover:glow-ring">
              <header className="flex items-center gap-2">
                <Terminal className="h-4 w-4 text-accent" aria-hidden />
                <h3 className="font-mono text-sm tracking-wide text-foreground">{group.title}</h3>
              </header>
              <div className="mt-5 space-y-4">
                {group.skills.map((s) => (
                  <SkillBar key={s.name} {...s} />
                ))}
              </div>
            </article>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

export function Projects() {
  return (
    <section id="projects" className="mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-24">
      <SectionHeading
        eyebrow="// projects"
        title="Featured Projects"
        intro="Beginner and learning projects built while studying security concepts."
      />
      <div className="mt-10 grid gap-5 md:grid-cols-2">
        {projects.map((p, i) => (
          <Reveal
            key={p.id}
            delay={i * 70}
            className={i === 0 ? "md:col-span-2" : ""}
          >
            <article className="glass group h-full rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1 hover:glow-ring">
              <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
                <h3 className="min-w-0 text-lg font-semibold tracking-tight">{p.title}</h3>
                <span className="shrink-0 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 font-mono text-[10px] uppercase tracking-widest text-primary">
                  {p.label}
                </span>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{p.description}</p>
              <p className="mt-4 font-mono text-xs text-accent">{p.technologies.join(" | ")}</p>
              <ul className="mt-4 grid gap-2 sm:grid-cols-2">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm text-foreground/85">
                    <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-primary" aria-hidden />
                    {f}
                  </li>
                ))}
              </ul>
              {p.note ? (
                <p className="mt-4 flex items-start gap-2 rounded-lg border border-border bg-secondary/40 p-3 text-xs leading-relaxed text-muted-foreground">
                  <TriangleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-accent" aria-hidden />
                  {p.note}
                </p>
              ) : null}
              <div className="mt-5 flex flex-wrap gap-3">
                <a
                  href={p.demoUrl}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
                >
                  View Project <ArrowUpRight className="h-4 w-4" aria-hidden />
                </a>
                <a
                  href={p.githubUrl}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-border px-4 py-2 text-sm font-medium text-foreground transition-colors hover:border-primary/50 hover:text-primary"
                >
                  <Github className="h-4 w-4" aria-hidden /> GitHub
                </a>
              </div>
            </article>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

export function Learning() {
  return (
    <section id="learning" className="mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-24">
      <SectionHeading eyebrow="// journey" title="My Cybersecurity Journey" />
      <ol className="relative mt-10 space-y-4 border-l border-border pl-6 sm:pl-8">
        {journey.map((item, i) => (
          <li key={item.step}>
            <Reveal delay={i * 70}>
              <div className="glass relative rounded-2xl p-6 transition-transform duration-300 hover:-translate-y-1">
                <span
                  className="absolute -left-[calc(1.5rem+5px)] top-8 h-2.5 w-2.5 rounded-full bg-primary sm:-left-[calc(2rem+5px)]"
                  aria-hidden
                />
                <p className="font-mono text-xs tracking-widest text-primary">{item.step}</p>
                <h3 className="mt-2 text-base font-semibold">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{item.body}</p>
              </div>
            </Reveal>
          </li>
        ))}
      </ol>

      <div className="mt-16">
        <SectionHeading eyebrow="// practice" title="Labs & Practice" />
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {labs.map((lab, i) => (
            <Reveal key={lab.name} delay={i * 70}>
              <article className="glass h-full rounded-2xl p-5 transition-transform duration-300 hover:-translate-y-1">
                <h3 className="font-mono text-sm text-accent">{lab.name}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{lab.detail}</p>
                <p className="mt-4 border-t border-border pt-3 font-mono text-[11px] text-muted-foreground">
                  Achievements will be added as I progress.
                </p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>

      <div className="mt-16">
        <SectionHeading eyebrow="// credentials" title="Certifications & Learning" />
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {credentials.map((c, i) => (
            <Reveal key={c.name} delay={i * 70}>
              <article className="glass h-full rounded-2xl border-dashed p-5">
                <h3 className="font-mono text-sm text-foreground">{c.name}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{c.detail}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

const contactIcons = { GitHub: Github, LinkedIn: Linkedin, Email: Mail } as const;

export function Contact() {
  return (
    <section id="contact" className="mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-24">
      <SectionHeading
        eyebrow="// contact"
        title="Let's Connect"
        intro="I'm always interested in learning, collaborating, and connecting with people in cybersecurity."
      />
      <div className="mt-10 grid gap-4 sm:grid-cols-3">
        {contacts.map((c, i) => {
          const Icon = contactIcons[c.name as keyof typeof contactIcons] ?? Mail;
          return (
            <Reveal key={c.name} delay={i * 80}>
              <a
                href={c.href}
                className="glass flex h-full items-center gap-4 rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1 hover:glow-ring"
              >
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg border border-accent/30 bg-accent/10">
                  <Icon className="h-5 w-5 text-accent" aria-hidden />
                </span>
                <span className="min-w-0">
                  <span className="block text-sm font-semibold">{c.name}</span>
                  <span className="block truncate font-mono text-xs text-muted-foreground">
                    {c.handle}
                  </span>
                </span>
              </a>
            </Reveal>
          );
        })}
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-10 text-center sm:px-6">
        <p className="text-sm text-muted-foreground">
          © 2026 Vishal. Built with curiosity and a passion for cybersecurity.
        </p>
        <p className="font-mono text-xs text-primary/80">
          Learning cybersecurity one project at a time.
        </p>
      </div>
    </footer>
  );
}
