import { useEffect, useState } from "react";

const lines = [
  { cmd: "whoami", out: "vishal" },
  { cmd: "focus", out: "cybersecurity" },
  { cmd: "status", out: "learning & building" },
];

const script = lines.flatMap((l) => [
  { kind: "cmd" as const, text: `$ ${l.cmd}` },
  { kind: "out" as const, text: l.out },
]);

export function TerminalCard() {
  const [index, setIndex] = useState(0);
  const [chars, setChars] = useState(0);

  useEffect(() => {
    const reduce =
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setIndex(script.length);
      return;
    }
    if (index >= script.length) return;
    const current = script[index]!;
    if (chars < current.text.length) {
      const t = setTimeout(() => setChars((c) => c + 1), current.kind === "cmd" ? 55 : 22);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => {
      setIndex((i) => i + 1);
      setChars(0);
    }, 380);
    return () => clearTimeout(t);
  }, [index, chars]);

  return (
    <div className="glass glow-ring rounded-2xl p-1 float-slow">
      <div className="rounded-xl bg-background/70 p-4 font-mono text-sm">
        <div className="flex items-center gap-2 border-b border-border pb-3">
          <span className="h-2.5 w-2.5 rounded-full bg-destructive/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-accent/60" />
          <span className="h-2.5 w-2.5 rounded-full bg-primary/70" />
          <span className="ml-2 truncate text-xs text-muted-foreground">vishal@sec — bash</span>
        </div>
        <div className="mt-3 space-y-1.5" aria-label="Terminal introduction">
          {script.slice(0, index).map((l, i) => (
            <p key={i} className={l.kind === "cmd" ? "text-primary" : "pl-3 text-foreground/80"}>
              {l.text}
            </p>
          ))}
          {index < script.length ? (
            <p
              className={
                script[index]!.kind === "cmd" ? "text-primary" : "pl-3 text-foreground/80"
              }
            >
              {script[index]!.text.slice(0, chars)}
              <span className="caret text-primary">▍</span>
            </p>
          ) : (
            <p className="text-primary">
              ${" "}
              <span className="caret">▍</span>
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
