import { ArrowRight, Mail } from "lucide-react";
import { TerminalCard } from "./TerminalCard";

export function Hero() {
  return (
    <section id="home" className="relative overflow-hidden">
      <div className="grid-bg pointer-events-none absolute inset-0 opacity-60" aria-hidden />
      <div
        className="pointer-events-none absolute -top-40 left-1/2 h-96 w-[42rem] -translate-x-1/2 rounded-full bg-primary/12 blur-3xl"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute bottom-0 right-0 h-72 w-72 rounded-full bg-accent/10 blur-3xl"
        aria-hidden
      />
      <div className="relative mx-auto grid max-w-6xl gap-12 px-4 py-20 sm:px-6 sm:py-28 lg:grid-cols-2 lg:items-center">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 font-mono text-[11px] uppercase tracking-[0.22em] text-primary">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" aria-hidden />
            Cybersecurity Enthusiast
          </span>
          <h1 className="mt-6 text-4xl font-semibold tracking-tight sm:text-6xl">
            Hi, I'm <span className="text-primary text-glow">Vishal</span>
          </h1>
          <p className="mt-4 text-2xl font-medium tracking-tight text-foreground/85 sm:text-3xl">
            Learning. Building. Securing.
          </p>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-muted-foreground">
            I'm a beginner cybersecurity enthusiast passionate about ethical hacking, network
            security, Linux, Python, and building practical security projects.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="#projects"
              className="inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
            >
              View My Projects <ArrowRight className="h-4 w-4" aria-hidden />
            </a>
            <a
              href="#contact"
              className="inline-flex items-center gap-2 rounded-lg border border-border px-5 py-3 text-sm font-semibold transition-colors hover:border-primary/50 hover:text-primary"
            >
              <Mail className="h-4 w-4" aria-hidden /> Contact Me
            </a>
          </div>
        </div>
        <TerminalCard />
      </div>
    </section>
  );
}
