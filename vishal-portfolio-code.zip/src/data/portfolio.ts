export type Project = {
  id: string;
  title: string;
  label: string;
  description: string;
  technologies: string[];
  features: string[];
  note?: string;
  demoUrl: string;
  githubUrl: string;
};

export const projects: Project[] = [
  {
    id: "password-strength-checker",
    title: "Password Strength Checker",
    label: "Beginner Project",
    description:
      "A Python-based tool that evaluates password strength using factors such as length, uppercase and lowercase characters, numbers, and special characters.",
    technologies: ["Python", "Regex", "Cybersecurity"],
    features: [
      "Password strength evaluation",
      "Character analysis",
      "Strength score",
      "Security recommendations",
    ],
    demoUrl: "#",
    githubUrl: "https://github.com/",
  },
  {
    id: "network-port-scanner",
    title: "Network Port Scanner",
    label: "Learning Project",
    description:
      "A beginner-friendly Python networking project that scans authorized systems for open TCP ports and helps identify exposed services.",
    technologies: ["Python", "Networking", "TCP/IP"],
    features: [
      "Port scanning",
      "Open port detection",
      "Basic service identification",
      "Scan results",
    ],
    note: "For educational use only. Scan only systems you own or have explicit permission to test.",
    demoUrl: "#",
    githubUrl: "https://github.com/",
  },
  {
    id: "file-integrity-monitor",
    title: "File Integrity Monitor",
    label: "Beginner Project",
    description:
      "A Python security tool that uses cryptographic hashes such as SHA-256 to detect unexpected changes to files.",
    technologies: ["Python", "SHA-256", "File Security"],
    features: [
      "Generate file hashes",
      "Compare file versions",
      "Detect modifications",
      "Display integrity warnings",
    ],
    demoUrl: "#",
    githubUrl: "https://github.com/",
  },
  {
    id: "log-analyzer",
    title: "Log Analyzer",
    label: "Learning Project",
    description:
      "A beginner cybersecurity project that analyzes authentication logs and identifies repeated failed login attempts and potentially suspicious activity.",
    technologies: ["Python", "Linux", "Log Analysis"],
    features: [
      "Log parsing",
      "Failed login detection",
      "IP address analysis",
      "Basic threat indicators",
    ],
    demoUrl: "#",
    githubUrl: "https://github.com/",
  },
  {
    id: "phishing-url-detector",
    title: "Phishing URL Detector",
    label: "Beginner Project",
    description:
      "A beginner project that analyzes URLs for common characteristics associated with potentially suspicious or phishing links.",
    technologies: ["Python", "URL Analysis", "Cybersecurity"],
    features: [
      "URL analysis",
      "Suspicious pattern detection",
      "Basic risk scoring",
      "Security recommendations",
    ],
    note: "Educational project — not a replacement for professional threat intelligence.",
    demoUrl: "#",
    githubUrl: "https://github.com/",
  },
];

export const skillGroups = [
  {
    title: "Cybersecurity",
    span: "lg:col-span-3",
    skills: [
      { name: "Ethical Hacking", level: 45 },
      { name: "Network Security", level: 50 },
      { name: "Vulnerability Analysis", level: 40 },
      { name: "Security Fundamentals", level: 60 },
    ],
  },
  {
    title: "Programming",
    span: "lg:col-span-3",
    skills: [
      { name: "Python", level: 55 },
      { name: "HTML", level: 70 },
      { name: "CSS", level: 65 },
      { name: "JavaScript", level: 45 },
    ],
  },
  {
    title: "Systems",
    span: "lg:col-span-3",
    skills: [
      { name: "Linux", level: 55 },
      { name: "Windows", level: 65 },
      { name: "Networking", level: 50 },
      { name: "Command Line", level: 60 },
    ],
  },
  {
    title: "Tools",
    span: "lg:col-span-3",
    skills: [
      { name: "Git", level: 50 },
      { name: "GitHub", level: 55 },
      { name: "Nmap", level: 40 },
      { name: "Wireshark", level: 35 },
    ],
  },
];

export const journey = [
  {
    step: "01",
    title: "Cybersecurity Fundamentals",
    body: "Learning networking, operating systems, security concepts, and common attack and defense techniques.",
  },
  {
    step: "02",
    title: "Linux & Networking",
    body: "Building practical knowledge of Linux commands, TCP/IP, ports, protocols, and network troubleshooting.",
  },
  {
    step: "03",
    title: "Python for Security",
    body: "Learning Python to automate tasks and build beginner cybersecurity tools.",
  },
  {
    step: "04",
    title: "Security Projects",
    body: "Applying what I learn by building practical cybersecurity projects.",
  },
  {
    step: "05",
    title: "Future Goals",
    body: "Explore ethical hacking, penetration testing, SOC operations, digital forensics, and security research.",
  },
];

export const labs = [
  { name: "TryHackMe", detail: "Guided rooms and hands-on security labs." },
  { name: "Hack The Box", detail: "Practice machines and challenge-based learning." },
  { name: "PortSwigger Web Security Academy", detail: "Web vulnerability theory and labs." },
  { name: "CTF Challenges", detail: "Beginner capture-the-flag practice." },
];

export const credentials = [
  { name: "Certification", detail: "Placeholder — to be added." },
  { name: "Course", detail: "Placeholder — to be added." },
  { name: "Workshop", detail: "Placeholder — to be added." },
  { name: "Training", detail: "Placeholder — to be added." },
];

export const contacts = [
  { name: "GitHub", handle: "github.com/vishal", href: "https://github.com/" },
  { name: "LinkedIn", handle: "linkedin.com/in/vishal", href: "https://linkedin.com/" },
  { name: "Email", handle: "vishal@example.com", href: "mailto:vishal@example.com" },
];

export const navItems = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "skills", label: "Skills" },
  { id: "projects", label: "Projects" },
  { id: "learning", label: "Learning" },
  { id: "contact", label: "Contact" },
];
